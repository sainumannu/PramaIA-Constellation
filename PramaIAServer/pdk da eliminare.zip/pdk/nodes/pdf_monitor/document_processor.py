"""
DocumentProcessor Node per PDK.
Estrae e processa testo da documenti PDF.
"""

import logging
import os
import tempfile
from typing import Dict, Any, List, Optional
from datetime import datetime

# Importazioni per l'elaborazione PDF
try:
    import fitz  # PyMuPDF
    from langchain.text_splitter import RecursiveCharacterTextSplitter
except ImportError:
    logging.warning("PDF processing libraries not available. Install PyMuPDF and langchain.")
    fitz = None
    
    # Mock RecursiveCharacterTextSplitter for environments without langchain
    class RecursiveCharacterTextSplitter:
        def __init__(self, **kwargs):
            pass
            
        def split_text(self, text):
            # Simple mock split by paragraphs
            return text.split("\n\n")


class DocumentProcessor:
    """
    Nodo PDK che estrae e processa testo da documenti PDF.
    """
    
    def __init__(self):
        """Initialize the node with logging."""
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def process(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process the PDF document and extract text.
        
        Args:
            inputs: Dictionary containing document parameters
            
        Returns:
            Dictionary with processed document
        """
        try:
            # Extract parameters
            file_path = inputs.get("file_path")
            file_content = inputs.get("file_content")
            chunking_strategy = inputs.get("chunking_strategy", "paragraph")
            chunk_size = inputs.get("chunk_size", 1000)
            chunk_overlap = inputs.get("chunk_overlap", 200)
            metadata = inputs.get("metadata", {})
            
            self.logger.info(f"Processing document with {chunking_strategy} chunking strategy")
            
            # Validate we have either file_path or file_content
            if not file_path and not file_content:
                raise ValueError("Either file_path or file_content must be provided")
            
            # Extract text from document
            document_text = self._extract_text(file_path, file_content)
            
            # Split text into chunks
            chunks = self._chunk_text(document_text, chunking_strategy, chunk_size, chunk_overlap)
            
            # Enrich metadata with document info
            enriched_metadata = self._enrich_metadata(metadata, document_text)
            
            return {
                "status": "success",
                "document_text": document_text,
                "chunks": chunks,
                "total_chunks": len(chunks),
                "metadata": enriched_metadata
            }
            
        except Exception as e:
            self.logger.error(f"Error in DocumentProcessor: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
                "error_type": type(e).__name__
            }
    
    def _extract_text(self, file_path: Optional[str], file_content: Optional[bytes]) -> str:
        """Extract text from a PDF document."""
        if not fitz:
            raise ImportError("PyMuPDF (fitz) is required for PDF processing")
            
        try:
            temp_file = None
            
            # If we have file_content but no file_path, save content to temp file
            if file_content and not file_path:
                temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
                temp_file.write(file_content)
                temp_file.close()
                file_path = temp_file.name
            
            # Open the PDF
            document = fitz.open(file_path)
            
            # Extract text from each page
            text = ""
            for page_num in range(len(document)):
                page = document.load_page(page_num)
                text += page.get_text()
                # Add page separator
                if page_num < len(document) - 1:
                    text += "\n\n--- Page Break ---\n\n"
            
            # Clean up temp file if created
            if temp_file:
                try:
                    os.unlink(temp_file.name)
                except Exception as e:
                    self.logger.warning(f"Failed to delete temp file: {str(e)}")
            
            return text
            
        except Exception as e:
            self.logger.error(f"Error extracting text: {str(e)}")
            # Clean up temp file if created and error occurred
            if temp_file:
                try:
                    os.unlink(temp_file.name)
                except:
                    pass
            raise
    
    def _chunk_text(self, text: str, strategy: str, chunk_size: int, chunk_overlap: int) -> List[str]:
        """Split text into chunks based on specified strategy."""
        try:
            if strategy == "paragraph":
                splitter = RecursiveCharacterTextSplitter(
                    chunk_size=chunk_size,
                    chunk_overlap=chunk_overlap,
                    length_function=len,
                    separators=["\n\n", "\n", ". ", " ", ""]
                )
            elif strategy == "sentence":
                splitter = RecursiveCharacterTextSplitter(
                    chunk_size=chunk_size,
                    chunk_overlap=chunk_overlap,
                    length_function=len,
                    separators=["\n\n", "\n", ".", "!", "?", ". ", " ", ""]
                )
            elif strategy == "fixed_size":
                splitter = RecursiveCharacterTextSplitter(
                    chunk_size=chunk_size,
                    chunk_overlap=chunk_overlap,
                    length_function=len,
                    separators=[" ", ""]
                )
            else:
                raise ValueError(f"Unknown chunking strategy: {strategy}")
                
            return splitter.split_text(text)
            
        except Exception as e:
            self.logger.error(f"Error chunking text: {str(e)}")
            raise
    
    def _enrich_metadata(self, metadata: Dict[str, Any], document_text: str) -> Dict[str, Any]:
        """Enrich metadata with document information."""
        try:
            enriched = metadata.copy()
            
            # Add basic document stats
            enriched["char_count"] = len(document_text)
            enriched["word_count"] = len(document_text.split())
            enriched["processed_at"] = datetime.now().isoformat()
            
            # Extract potential title
            lines = document_text.split("\n")
            if lines and lines[0].strip():
                potential_title = lines[0].strip()
                # Only use as title if reasonably short
                if len(potential_title) < 100:
                    enriched["extracted_title"] = potential_title
            
            # Count pages (based on our page break markers)
            page_count = document_text.count("--- Page Break ---") + 1
            enriched["estimated_page_count"] = page_count
            
            return enriched
            
        except Exception as e:
            self.logger.error(f"Error enriching metadata: {str(e)}")
            # Return original metadata if enrichment fails
            return metadata


# Node factory function
def create_node():
    """Create and return the DocumentProcessor node."""
    return DocumentProcessor()
