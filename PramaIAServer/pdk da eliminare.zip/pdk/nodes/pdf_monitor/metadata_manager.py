"""
MetadataManager Node per PDK.
Gestisce operazioni sui metadati dei documenti.
"""

import logging
import json
import copy
from typing import Dict, Any, List, Optional, Union
from datetime import datetime

# Importazione per la validazione degli schemi JSON
try:
    import jsonschema
except ImportError:
    logging.warning("jsonschema not available. Validation functionality will be limited.")
    jsonschema = None


class MetadataManager:
    """
    Nodo PDK che gestisce operazioni sui metadati dei documenti.
    """
    
    def __init__(self):
        """Initialize the node with logging."""
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def process(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process the metadata operations based on the specified operation.
        
        Args:
            inputs: Dictionary containing metadata operation parameters
            
        Returns:
            Dictionary with operation results
        """
        try:
            # Extract operation parameters
            operation = inputs.get("operation", "update")
            current_metadata = inputs.get("current_metadata", {})
            new_metadata = inputs.get("new_metadata", {})
            validation_schema = inputs.get("validation_schema")
            
            self.logger.info(f"Performing {operation} operation on metadata")
            
            # Validate inputs
            if not isinstance(current_metadata, dict):
                raise ValueError("current_metadata must be a dictionary")
                
            if not isinstance(new_metadata, dict):
                raise ValueError("new_metadata must be a dictionary")
            
            # Perform the requested operation
            if operation == "update":
                result_metadata = self._update_metadata(current_metadata, new_metadata)
            elif operation == "merge":
                result_metadata = self._merge_metadata(current_metadata, new_metadata)
            elif operation == "extract":
                result_metadata = self._extract_metadata(current_metadata, new_metadata, inputs.get("content", ""))
            else:
                raise ValueError(f"Unsupported operation: {operation}")
            
            # Add operation timestamp
            result_metadata["metadata_updated_at"] = datetime.now().isoformat()
            
            # Validate the resulting metadata if schema provided
            is_valid, validation_errors = self._validate_metadata(result_metadata, validation_schema)
            
            return {
                "status": "success" if is_valid else "validation_error",
                "metadata": result_metadata,
                "is_valid": is_valid,
                "validation_errors": validation_errors,
                "operation": operation
            }
            
        except Exception as e:
            self.logger.error(f"Error in MetadataManager: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
                "error_type": type(e).__name__
            }
    
    def _update_metadata(self, current_metadata: Dict[str, Any], new_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Replace the current metadata with new metadata.
        Preserves certain system fields if they exist.
        """
        # Make a deep copy of the new metadata
        result = copy.deepcopy(new_metadata)
        
        # Preserve system fields from current metadata if they exist
        system_fields = ["document_id", "created_at", "file_path", "source_id"]
        for field in system_fields:
            if field in current_metadata and field not in result:
                result[field] = current_metadata[field]
        
        return result
    
    def _merge_metadata(self, current_metadata: Dict[str, Any], new_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Intelligently merge current and new metadata.
        Handles nested dictionaries, lists, and primitive values.
        """
        # Start with a deep copy of current metadata
        result = copy.deepcopy(current_metadata)
        
        # Recursive helper function for deep merging
        def deep_merge(target, source):
            for key, value in source.items():
                if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                    # Recursively merge nested dictionaries
                    deep_merge(target[key], value)
                elif key in target and isinstance(target[key], list) and isinstance(value, list):
                    # Merge lists without duplicates for certain fields
                    if key in ["tags", "categories", "labels"]:
                        target[key] = list(set(target[key] + value))
                    else:
                        # For other lists, append new values
                        target[key].extend(value)
                else:
                    # Simple value replacement
                    target[key] = value
        
        # Perform the deep merge
        deep_merge(result, new_metadata)
        
        return result
    
    def _extract_metadata(self, current_metadata: Dict[str, Any], 
                          hints: Dict[str, Any], content: str) -> Dict[str, Any]:
        """
        Extract metadata from document content based on hints.
        This is a simplified implementation - in a real system this might use 
        ML models or more sophisticated extraction techniques.
        """
        # Start with current metadata
        result = copy.deepcopy(current_metadata)
        
        # Process basic content stats
        if content:
            # Add basic document stats if not already present
            if "stats" not in result:
                result["stats"] = {}
                
            result["stats"]["char_count"] = len(content)
            result["stats"]["word_count"] = len(content.split())
            result["stats"]["line_count"] = content.count('\n') + 1
            
            # Extract potential title from first line
            lines = content.split('\n')
            if lines and lines[0].strip() and len(lines[0].strip()) < 100:
                result["extracted_title"] = lines[0].strip()
            
            # Simple keyword extraction if hints provide keywords to look for
            if "keywords" in hints:
                found_keywords = []
                content_lower = content.lower()
                for keyword in hints.get("keywords", []):
                    if keyword.lower() in content_lower:
                        found_keywords.append(keyword)
                        
                if found_keywords:
                    result["keywords"] = list(set(result.get("keywords", []) + found_keywords))
        
        # Apply any explicit metadata from hints
        if "metadata" in hints:
            result = self._merge_metadata(result, hints["metadata"])
        
        return result
    
    def _validate_metadata(self, metadata: Dict[str, Any], 
                          schema: Optional[Dict[str, Any]]) -> tuple[bool, Optional[List[str]]]:
        """
        Validate metadata against a JSON schema if provided.
        Returns (is_valid, validation_errors)
        """
        # If no schema, consider valid
        if not schema:
            return True, None
            
        if not jsonschema:
            self.logger.warning("jsonschema library not available, skipping validation")
            return True, ["Validation skipped: jsonschema library not available"]
        
        try:
            jsonschema.validate(instance=metadata, schema=schema)
            return True, None
        except jsonschema.exceptions.ValidationError as e:
            self.logger.warning(f"Metadata validation failed: {e}")
            # Format validation errors in a readable way
            error_path = "/".join(str(p) for p in e.path)
            error_message = f"At {error_path}: {e.message}"
            return False, [error_message]
        except Exception as e:
            self.logger.error(f"Unexpected error during validation: {e}")
            return False, [f"Validation error: {str(e)}"]


# Node factory function
def create_node():
    """Create and return the MetadataManager node."""
    return MetadataManager()
