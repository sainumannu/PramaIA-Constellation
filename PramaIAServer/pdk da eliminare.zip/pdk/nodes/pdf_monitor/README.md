# VectorStore Operations Node

Nodo PDK che fornisce operazioni CRUD complete sul vectorstore.

## Descrizione

Questo nodo fornisce un'interfaccia unificata per operazioni sul vectorstore:
- Aggiunta documenti
- Recupero documenti
- Aggiornamento documenti
- Rimozione documenti
- Query sui documenti

## Input

- `operation_type`: Tipo di operazione (`add`, `get`, `update`, `delete`, `query`)
- `document_id`: ID del documento (per get, update, delete)
- `document_content`: Contenuto del documento (per add, update)
- `document_metadata`: Metadati del documento (per add, update)
- `query_text`: Testo della query (per query)
- `namespace`: Namespace del vectorstore
- `collection_name`: Nome della collezione

## Output

- `status`: Stato dell'operazione
- `document_id`: ID del documento elaborato
- `result`: Risultato dell'operazione (dipende dal tipo)

## Esempio di utilizzo

```json
{
  "operation_type": "add",
  "document_content": "Questo è il contenuto del documento da aggiungere.",
  "document_metadata": {
    "source": "pdf-monitor",
    "filename": "documento.pdf"
  }
}
```

## Note

- Per operazioni batch, utilizzare più istanze del nodo in sequenza
- Gestisce automaticamente la connessione al vectorstore
- Supporta operazioni su vari tipi di vectorstore (Chroma, FAISS, etc.)
