"""
VectorStoreOperations Node per PDK.
Fornisce un'interfaccia unificata per operazioni CRUD sul vectorstore.
"""

import logging
import uuid
from typing import Dict, Any, List, Optional, Union
from datetime import datetime

# Importazioni per il vectorstore
try:
    from backend.core.rag_vectorstore import (
        get_vectorstore, 
        add_documents_to_vectorstore,
        remove_documents_from_vectorstore
    )
    from backend.core.rag_chains_prompts import get_openai_embeddings
    from langchain.docstore.document import Document
except ImportError:
    # Fallback per test o ambienti senza backend
    logging.warning("Backend modules not available. Using mock implementations.")
    
    def get_vectorstore(*args, **kwargs):
        logging.warning("Using mock vectorstore")
        return MockVectorStore()
    
    def add_documents_to_vectorstore(*args, **kwargs):
        logging.warning("Using mock add_documents_to_vectorstore")
        return True
    
    def remove_documents_from_vectorstore(*args, **kwargs):
        logging.warning("Using mock remove_documents_from_vectorstore")
        return True
    
    def get_openai_embeddings(*args, **kwargs):
        logging.warning("Using mock embeddings")
        return MockEmbeddings()
    
    class Document:
        def __init__(self, page_content, metadata=None):
            self.page_content = page_content
            self.metadata = metadata or {}
    
    class MockVectorStore:
        def similarity_search(self, *args, **kwargs):
            return [Document(page_content="Mock result", metadata={"source": "mock"})]
            
        def similarity_search_with_score(self, *args, **kwargs):
            return [(Document(page_content="Mock result", metadata={"source": "mock"}), 0.95)]
            
        def add_documents(self, *args, **kwargs):
            return True
            
        def delete(self, *args, **kwargs):
            return True
    
    class MockEmbeddings:
        def embed_documents(self, texts):
            return [[0.1] * 10 for _ in texts]  # Mock embeddings
            
        def embed_query(self, text):
            return [0.1] * 10  # Mock query embedding


class VectorStoreOperations:
    """
    Nodo PDK che fornisce operazioni CRUD sul vectorstore.
    """
    
    def __init__(self):
        """Initialize the node with logging."""
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def process(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process the inputs and perform the requested operation.
        
        Args:
            inputs: Dictionary containing operation parameters
            
        Returns:
            Dictionary with operation results
        """
        try:
            # Extract operation parameters
            operation_type = inputs.get("operation_type")
            document_id = inputs.get("document_id")
            document_content = inputs.get("document_content")
            document_metadata = inputs.get("document_metadata", {})
            query_text = inputs.get("query_text")
            namespace = inputs.get("namespace", "default")
            collection_name = inputs.get("collection_name", "default")
            
            self.logger.info(f"Performing {operation_type} operation on vectorstore")
            
            # Validate input based on operation type
            self._validate_inputs(operation_type, document_id, document_content, query_text)
            
            # Get vectorstore reference
            vectorstore = self._get_vectorstore(collection_name, namespace)
            
            # Perform the requested operation
            if operation_type == "add":
                return self._add_document(vectorstore, document_content, document_metadata)
            elif operation_type == "get":
                return self._get_document(vectorstore, document_id, document_metadata)
            elif operation_type == "update":
                return self._update_document(vectorstore, document_id, document_content, document_metadata)
            elif operation_type == "delete":
                return self._delete_document(vectorstore, document_id, document_metadata)
            elif operation_type == "query":
                return self._query_documents(vectorstore, query_text, inputs.get("top_k", 5))
            else:
                raise ValueError(f"Unsupported operation type: {operation_type}")
                
        except Exception as e:
            self.logger.error(f"Error in VectorStoreOperations: {str(e)}")
            return {
                "status": "error",
                "error": str(e),
                "error_type": type(e).__name__
            }
    
    def _validate_inputs(self, operation_type: str, document_id: Optional[str], 
                        document_content: Optional[str], query_text: Optional[str]) -> None:
        """Validate inputs based on operation type."""
        if operation_type == "add" and not document_content:
            raise ValueError("document_content is required for add operation")
        
        if operation_type in ["get", "update", "delete"] and not document_id:
            raise ValueError(f"document_id is required for {operation_type} operation")
            
        if operation_type == "update" and not document_content:
            raise ValueError("document_content is required for update operation")
            
        if operation_type == "query" and not query_text:
            raise ValueError("query_text is required for query operation")
    
    def _get_vectorstore(self, collection_name: str, namespace: str) -> Any:
        """Get reference to vectorstore."""
        try:
            vectorstore = get_vectorstore(collection_name=collection_name, namespace=namespace)
            if not vectorstore:
                raise ValueError("Failed to get vectorstore reference")
            return vectorstore
        except Exception as e:
            self.logger.error(f"Error getting vectorstore: {str(e)}")
            raise
    
    def _add_document(self, vectorstore: Any, content: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Add document to vectorstore."""
        try:
            # Generate a document ID if not provided in metadata
            document_id = metadata.get("document_id", f"doc_{uuid.uuid4().hex}")
            
            # Ensure document_id is in metadata
            metadata["document_id"] = document_id
            
            # Add timestamp if not provided
            if "timestamp" not in metadata:
                metadata["timestamp"] = datetime.now().isoformat()
            
            # Create document object
            doc = Document(
                page_content=content,
                metadata=metadata
            )
            
            # Get embeddings service
            embeddings_service = get_openai_embeddings()
            
            # Add to vectorstore
            source_filename = metadata.get("source_filename", document_id)
            success = add_documents_to_vectorstore(
                docs=[doc],
                embeddings_service=embeddings_service,
                filename=source_filename
            )
            
            if not success:
                raise ValueError("Failed to add document to vectorstore")
            
            return {
                "status": "success",
                "document_id": document_id,
                "operation": "add"
            }
            
        except Exception as e:
            self.logger.error(f"Error adding document: {str(e)}")
            raise
    
    def _get_document(self, vectorstore: Any, document_id: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Get document from vectorstore."""
        try:
            # Use document_id to query the vectorstore
            results = vectorstore.similarity_search(
                query=f"id:{document_id}", 
                k=1,
                filter={"document_id": document_id}
            )
            
            if not results:
                return {
                    "status": "not_found",
                    "document_id": document_id,
                    "operation": "get"
                }
            
            document = results[0]
            
            return {
                "status": "success",
                "document_id": document_id,
                "document_content": document.page_content,
                "document_metadata": document.metadata,
                "operation": "get"
            }
            
        except Exception as e:
            self.logger.error(f"Error retrieving document: {str(e)}")
            raise
    
    def _update_document(self, vectorstore: Any, document_id: str, 
                        content: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Update document in vectorstore."""
        try:
            # First, remove existing document
            success = remove_documents_from_vectorstore(document_id)
            if not success:
                self.logger.warning(f"Document {document_id} not found for update")
            
            # Ensure document_id is in metadata
            metadata["document_id"] = document_id
            
            # Add timestamp
            metadata["updated_at"] = datetime.now().isoformat()
            
            # Create document object
            doc = Document(
                page_content=content,
                metadata=metadata
            )
            
            # Get embeddings service
            embeddings_service = get_openai_embeddings()
            
            # Add updated document
            source_filename = metadata.get("source_filename", document_id)
            success = add_documents_to_vectorstore(
                docs=[doc],
                embeddings_service=embeddings_service,
                filename=source_filename
            )
            
            if not success:
                raise ValueError("Failed to update document in vectorstore")
            
            return {
                "status": "success",
                "document_id": document_id,
                "operation": "update"
            }
            
        except Exception as e:
            self.logger.error(f"Error updating document: {str(e)}")
            raise
    
    def _delete_document(self, vectorstore: Any, document_id: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Delete document from vectorstore."""
        try:
            # Remove document
            success = remove_documents_from_vectorstore(document_id)
            
            if not success:
                return {
                    "status": "not_found",
                    "document_id": document_id,
                    "operation": "delete"
                }
            
            return {
                "status": "success",
                "document_id": document_id,
                "operation": "delete"
            }
            
        except Exception as e:
            self.logger.error(f"Error deleting document: {str(e)}")
            raise
    
    def _query_documents(self, vectorstore: Any, query_text: str, top_k: int) -> Dict[str, Any]:
        """Query documents from vectorstore."""
        try:
            # Search with scores
            results = vectorstore.similarity_search_with_score(
                query=query_text,
                k=top_k
            )
            
            # Format results
            documents = []
            for doc, score in results:
                documents.append({
                    "content": doc.page_content,
                    "metadata": doc.metadata,
                    "score": float(score)  # Convert to float for JSON serialization
                })
            
            return {
                "status": "success",
                "query": query_text,
                "documents": documents,
                "total_results": len(documents),
                "operation": "query"
            }
            
        except Exception as e:
            self.logger.error(f"Error querying documents: {str(e)}")
            raise


# Node factory function
def create_node():
    """Create and return the VectorStoreOperations node."""
    return VectorStoreOperations()
