"""
EventLogger Node per PDK.
Registra gli eventi nel sistema PDF Monitor.
"""

import logging
import sqlite3
import json
import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional, Union

class EventLogger:
    """
    Nodo per la registrazione degli eventi del sistema PDF Monitor.
    Registra eventi come elaborazione file, rilevamento nuovi file, 
    aggiornamento metadati, errori e esecuzione workflow.
    """

    def __init__(self, logger=None):
        """
        Inizializza il nodo EventLogger.
        
        Args:
            logger: Logger opzionale per la registrazione delle attività.
        """
        self.logger = logger or logging.getLogger(__name__)
        self.logger.info("EventLogger inizializzato")
        self.default_db_path = "pdf_monitor_events.db"

    def process(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Registra un evento nel database.
        
        Args:
            inputs: Dizionario con i parametri di input.
                - event_type: Tipo di evento
                - file_name: Nome del file
                - status: Stato dell'evento
                - document_id: ID del documento (opzionale)
                - metadata: Metadati associati (opzionale)
                - event_data: Dati aggiuntivi (opzionale)
                - event_source: Sorgente dell'evento (opzionale)
                - user_id: ID utente (opzionale)
                - db_path: Percorso del database (opzionale)
                
        Returns:
            Dict con i risultati dell'operazione:
                - success: Booleano che indica se l'evento è stato registrato
                - event_id: ID univoco dell'evento
                - timestamp: Timestamp di registrazione
                - error: Messaggio di errore (solo in caso di fallimento)
        """
        try:
            # Estrazione dei parametri di input con validazione dei tipi
            event_type = str(inputs.get("event_type", ""))
            file_name = str(inputs.get("file_name", ""))
            status = str(inputs.get("status", ""))
            document_id = inputs.get("document_id")
            if document_id is not None:
                document_id = str(document_id)
            
            metadata = inputs.get("metadata", {})
            event_data = inputs.get("event_data", {})
            event_source = str(inputs.get("event_source", "pdk_workflow"))
            user_id = inputs.get("user_id")
            if user_id is not None:
                user_id = str(user_id)
                
            db_path = str(inputs.get("db_path", self.default_db_path))
            
            # Validazione degli input obbligatori
            self._validate_inputs(event_type, file_name, status, document_id, metadata)
            
            # Generazione event_id e timestamp
            event_id = str(uuid.uuid4())
            timestamp = datetime.now().isoformat()
            
            # Registrazione dell'evento nel database
            self._log_event_to_db(
                db_path, event_id, timestamp, event_type, file_name, status,
                document_id, metadata, event_data, event_source, user_id
            )
            
            self.logger.info(f"Evento {event_type} registrato con ID {event_id}")
            
            return {
                "success": True,
                "event_id": event_id,
                "timestamp": timestamp
            }
            
        except Exception as e:
            self.logger.error(f"Errore durante la registrazione dell'evento: {str(e)}")
            return {
                "success": False,
                "event_id": "",
                "timestamp": datetime.now().isoformat(),
                "error": str(e)
            }

    def _validate_inputs(self, event_type: str, file_name: str, status: str, 
                         document_id: Optional[str], metadata: Any) -> None:
        """
        Valida i parametri di input.
        
        Args:
            event_type: Tipo di evento
            file_name: Nome del file
            status: Stato dell'evento
            document_id: ID del documento (opzionale)
            metadata: Metadati associati (opzionale)
            
        Raises:
            ValueError: Se i parametri obbligatori non sono validi
        """
        valid_event_types = [
            "file_processed", "file_detected", "metadata_updated", 
            "error", "workflow_executed", "custom"
        ]
        
        valid_statuses = ["success", "error", "warning", "info"]
        
        if not event_type:
            raise ValueError("Il tipo di evento è obbligatorio")
        
        if event_type not in valid_event_types:
            raise ValueError(f"Tipo di evento non valido. Valori ammessi: {', '.join(valid_event_types)}")
        
        if not file_name:
            raise ValueError("Il nome del file è obbligatorio")
        
        if not status:
            raise ValueError("Lo stato dell'evento è obbligatorio")
        
        if status not in valid_statuses:
            raise ValueError(f"Stato non valido. Valori ammessi: {', '.join(valid_statuses)}")
        
        if metadata and not isinstance(metadata, dict):
            raise ValueError("I metadati devono essere un dizionario")

    def _log_event_to_db(self, db_path: str, event_id: str, timestamp: str, 
                         event_type: str, file_name: str, status: str,
                         document_id: Optional[str], metadata: Any, event_data: Any,
                         event_source: str, user_id: Optional[str]) -> None:
        """
        Registra un evento nel database SQLite.
        
        Args:
            db_path: Percorso del database
            event_id: ID univoco dell'evento
            timestamp: Timestamp di registrazione
            event_type: Tipo di evento
            file_name: Nome del file
            status: Stato dell'evento
            document_id: ID del documento (opzionale)
            metadata: Metadati associati (opzionale)
            event_data: Dati aggiuntivi (opzionale)
            event_source: Sorgente dell'evento
            user_id: ID utente (opzionale)
        """
        # Connessione al database
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        try:
            # Creazione della tabella se non esiste
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS pdf_monitor_events (
                event_id TEXT PRIMARY KEY,
                timestamp TEXT,
                event_type TEXT,
                file_name TEXT,
                status TEXT,
                document_id TEXT,
                metadata TEXT,
                event_data TEXT,
                event_source TEXT,
                user_id TEXT
            )
            ''')
            
            # Conversione degli oggetti in JSON
            metadata_json = json.dumps(metadata) if metadata else "{}"
            event_data_json = json.dumps(event_data) if event_data else "{}"
            
            # Inserimento dell'evento
            cursor.execute('''
            INSERT INTO pdf_monitor_events (
                event_id, timestamp, event_type, file_name, status,
                document_id, metadata, event_data, event_source, user_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                event_id, timestamp, event_type, file_name, status,
                document_id, metadata_json, event_data_json, event_source, user_id
            ))
            
            # Commit della transazione
            conn.commit()
            
        except Exception as e:
            self.logger.error(f"Errore nel database: {str(e)}")
            conn.rollback()
            raise
        finally:
            conn.close()

    def _get_events(self, db_path: str, filters: Optional[Dict[str, Any]] = None, 
                   limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Recupera eventi dal database applicando filtri opzionali.
        
        Args:
            db_path: Percorso del database
            filters: Filtri da applicare (chiave/valore)
            limit: Numero massimo di risultati
            offset: Offset per la paginazione
            
        Returns:
            Lista di eventi come dizionari
        """
        filters = filters or {}
        
        # Connessione al database
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row  # Per ottenere i risultati come dizionari
        cursor = conn.cursor()
        
        try:
            # Costruzione della query
            query = "SELECT * FROM pdf_monitor_events"
            params = []
            
            # Aggiunta filtri
            if filters:
                conditions = []
                for key, value in filters.items():
                    if key in ["event_id", "event_type", "file_name", "status", 
                              "document_id", "event_source", "user_id"]:
                        conditions.append(f"{key} = ?")
                        params.append(value)
                
                if conditions:
                    query += " WHERE " + " AND ".join(conditions)
            
            # Aggiunta ordinamento, limit e offset
            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Esecuzione query
            cursor.execute(query, params)
            
            # Conversione risultati
            results = []
            for row in cursor.fetchall():
                event = dict(row)
                # Conversione JSON in dizionari
                event["metadata"] = json.loads(event["metadata"]) if event["metadata"] else {}
                event["event_data"] = json.loads(event["event_data"]) if event["event_data"] else {}
                results.append(event)
            
            return results
            
        except Exception as e:
            self.logger.error(f"Errore durante il recupero eventi: {str(e)}")
            return []
        finally:
            conn.close()

    def _clear_events(self, db_path: str, older_than: Optional[datetime] = None) -> int:
        """
        Elimina eventi dal database, opzionalmente solo quelli più vecchi di una certa data.
        
        Args:
            db_path: Percorso del database
            older_than: Data limite, verranno eliminati solo gli eventi precedenti
            
        Returns:
            Numero di eventi eliminati
        """
        # Connessione al database
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        try:
            # Costruzione della query
            query = "DELETE FROM pdf_monitor_events"
            params = []
            
            # Filtro per data
            if older_than:
                timestamp = older_than.isoformat()
                query += " WHERE timestamp < ?"
                params.append(timestamp)
            
            # Esecuzione query
            cursor.execute(query, params)
            
            # Commit e conteggio righe eliminate
            deleted_count = cursor.rowcount
            conn.commit()
            
            return deleted_count
            
        except Exception as e:
            self.logger.error(f"Errore durante l'eliminazione eventi: {str(e)}")
            conn.rollback()
            return 0
        finally:
            conn.close()
