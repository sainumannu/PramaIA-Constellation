"""
Plugin PDF Monitor per PDK.
Gestisce il monitoraggio, l'elaborazione e la gestione di documenti PDF.
"""

class PDFMonitorPlugin:
    """
    Plugin per il monitoraggio e la gestione dei documenti PDF.
    Fornisce nodi per operazioni di gestione metadati, logging eventi,
    parsing di file PDF e operazioni su vectorstore.
    """
    
    def __init__(self):
        """Inizializza il plugin PDF Monitor."""
        pass
        
    def register(self):
        """Registra i nodi del plugin."""
        return {
            "metadata_manager": "metadata_manager.py",
            "event_logger": "event_logger.py",
            "file_parsing": "file_parsing.py",
            "document_processor": "document_processor.py",
            "vector_store_operations": "vector_store_operations.py"
        }
